import 'package:appcontabancaria/views/app_contabancaria.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const AppContaBancaria());
}
