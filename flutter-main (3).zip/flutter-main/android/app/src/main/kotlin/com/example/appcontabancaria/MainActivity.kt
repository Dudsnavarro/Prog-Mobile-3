package com.example.appcontabancaria

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
